# Quick Start Guide - Discovery Readiness Check

## Installation (One-time setup)

### Option A: Using Standalone Binary (No Installation Required!)

```bash
# Extract the package
tar -xzf discovery_readiness_check_v1.1_linux.tar.gz

# Navigate to directory
cd discovery_readiness_check_v1.1_linux

# Make executable (if needed)
chmod +x discovery_readiness_check

# That's it! Ready to use.
```

### Option B: Using Python Script

```bash
# Install Python dependencies
pip install -r requirements.txt

# Make script executable (Linux/Mac)
chmod +x discovery_readiness_check.py
```

## Basic Workflow

### 1. Create Input Template

**Binary:**
```bash
./discovery_readiness_check --create-template my_targets.xlsx
```

**Python:**
```bash
python discovery_readiness_check.py --create-template my_targets.xlsx
```

### 2. Edit Excel File

Open `my_targets.xlsx` and fill in your targets:

| IP_or_CIDR | OS_Type | Username | Password | Domain |
|------------|---------|----------|----------|--------|
| 192.168.1.10 | | admin | pass123 | |
| 10.0.0.0/24 | | root | rootpass | |
| 172.16.0.5 | | john.doe | domainpass | CORP |

**Remember:**
- Leave OS_Type blank for auto-detection
- Add Domain only for Windows domain accounts
- Delete the yellow help row before running

### 3. Run Scan

**Binary:**
```bash
./discovery_readiness_check -i my_targets.xlsx -o results.xlsx
```

**Python:**
```bash
python discovery_readiness_check.py -i my_targets.xlsx -o results.xlsx
```

### 4. Review Results

Open `results.xlsx`:
- **Results** sheet: Detailed checks per IP (color-coded)
- **Summary** sheet: Overall statistics

## Common Scenarios

### Scenario 1: Mixed Environment (Auto-detect everything)
```excel
IP_or_CIDR     | OS_Type | Username      | Password   | Domain
192.168.1.10   |         | admin         | pass123    |
192.168.1.11   |         | root          | rootpass   |
10.0.0.5       |         | administrator | winpass    |
```

### Scenario 2: Known Linux Network
```excel
IP_or_CIDR     | OS_Type | Username | Password   | Domain
192.168.1.0/24 | Linux   | root     | rootpass   |
```

### Scenario 3: Windows Domain Environment
```excel
IP_or_CIDR     | OS_Type | Username  | Password    | Domain
172.16.0.0/24  | Windows | svc_scan  | SecurePass1 | CONTOSO
10.10.10.5     | Windows | admin     | LocalPass   |
```

### Scenario 4: Multiple Credential Groups
```excel
IP_or_CIDR     | OS_Type | Username | Password  | Domain
192.168.1.0/28 |         | group1   | pass1     |
192.168.2.0/28 |         | group2   | pass2     |
10.0.0.10      |         | special  | pass3     | DOMAIN1
```

## Command Options

**Binary:**
```bash
# Basic scan
./discovery_readiness_check -i input.xlsx -o output.xlsx

# Verbose mode (for troubleshooting)
./discovery_readiness_check -i input.xlsx -o output.xlsx -v

# Adjust concurrent workers (default: 20)
./discovery_readiness_check -i input.xlsx -o output.xlsx -w 10

# Create template only
./discovery_readiness_check --create-template template.xlsx
```

**Python:**
```bash
# Basic scan
python discovery_readiness_check.py -i input.xlsx -o output.xlsx

# Verbose mode (for troubleshooting)
python discovery_readiness_check.py -i input.xlsx -o output.xlsx -v

# Adjust concurrent workers (default: 20)
python discovery_readiness_check.py -i input.xlsx -o output.xlsx -w 10

# Create template only
python discovery_readiness_check.py --create-template template.xlsx
```

## Reading Results

### Green Cells = PASS
- Port is open
- Authentication succeeded
- Command available with sudo

### Red Cells = FAIL
- Port closed
- Authentication failed
- Command missing or no sudo

### Output Columns Explained

**For All Hosts:**
- OS Type: Linux/Windows/Unknown
- OS Detected: Auto (detected) or Manual (you specified)
- Port Open: 22 for Linux, 5985 for Windows
- Authentication: Success/Failed

**For Linux:**
- Sudo Available: Can run sudo without password
- For each command (netstat, route, ifconfig, crontab):
  - Available: Command exists on system
  - Sudo NOPASSWD: Can run with sudo without password

**For Windows:**
- Domain: Shows domain if domain auth was used
- Admin Privileges: User has admin rights

## Troubleshooting Quick Fixes

### Linux Issues
```bash
# On target: Enable SSH
sudo systemctl start sshd
sudo systemctl enable sshd

# On target: Allow SSH through firewall
sudo ufw allow 22

# On target: Setup sudo NOPASSWD
echo "username ALL=(ALL) NOPASSWD: ALL" | sudo tee /etc/sudoers.d/username
```

### Windows Issues
```powershell
# On target: Enable WinRM
Enable-PSRemoting -Force

# On target: Allow remote connections
Set-Item WSMan:\localhost\Client\TrustedHosts -Value "*" -Force

# On target: Add user to Administrators
Add-LocalGroupMember -Group "Administrators" -Member "username"

# For domain users
Add-LocalGroupMember -Group "Administrators" -Member "DOMAIN\username"
```

## Tips

1. **Start Small**: Test with 2-3 IPs before scanning large ranges
2. **Use Auto-Detection**: Let the tool figure out OS type
3. **Group by Credentials**: Minimize rows by using CIDR for same credentials
4. **Check Verbose Output**: Use `-v` flag to see what's happening
5. **Verify Connectivity First**: Ping targets before running full scan

## Success Criteria

For **full readiness**, each host should show:

**Linux:**
- ✅ Port Open: Yes
- ✅ Authentication: Success
- ✅ Sudo Available: Yes
- ✅ All commands: Available = Yes, Sudo NOPASSWD = Yes

**Windows:**
- ✅ Port Open: Yes
- ✅ Authentication: Success
- ✅ Admin Privileges: Yes

## Get Help

If you encounter issues:
1. Run with `-v` flag for detailed logs
2. Check the "Error Details" column in results
3. Review the troubleshooting section in README.md
4. Verify network connectivity: `ping <target_ip>`
5. Test credentials manually before running scan
