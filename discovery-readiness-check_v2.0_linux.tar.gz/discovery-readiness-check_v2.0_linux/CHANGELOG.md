# Changelog - Discovery Readiness Check Utility

## Version 1.1 - Enhanced Release (2024-10-23)

### New Features

#### 1. Automatic OS Detection
- **No need to specify OS type manually**
- Tool automatically detects Linux or Windows based on open ports
- Detection logic:
  - SSH (port 22) open → Linux
  - WinRM (port 5985) open → Windows
  - Both open → SSH banner detection attempted
  - Neither open → Marked as Unknown
- OS_Type column is now **optional** in input Excel
- Results show "Auto" vs "Manual" detection method

#### 2. Windows Domain Authentication Support
- **Full support for Active Directory domain accounts**
- New optional "Domain" column in input Excel
- Format: `DOMAIN\username` automatically constructed
- Works with NTLM authentication over WinRM
- Supports mixed local and domain accounts in same scan
- Domain name displayed in results for Windows hosts

#### 3. Enhanced Input Template
- Added Domain column for Windows domain support
- Included help/example row (highlighted in yellow)
- Better column descriptions
- Shows examples of auto-detection usage
- Clear instructions for optional vs required columns

#### 4. Improved Results Output
- New column: "OS Detected" (Auto/Manual)
- Domain shown for Windows hosts using domain auth
- Better error messages for failed auto-detection
- Enhanced color coding in Excel output

### Improvements
- Better error handling for ambiguous scenarios (both ports open)
- More detailed logging for OS detection process
- Clearer validation messages during input parsing
- Updated documentation with new features

### Files Modified
- `discovery_readiness_check.py` - Main script (v1.0 → v1.1)
- `README.md` - Full documentation update
- `requirements.txt` - No changes (same dependencies)
- `QUICK_START.md` - NEW: Quick reference guide
- `CHANGELOG.md` - NEW: This file

### Migration from v1.0

**Backward Compatibility:** ✅ **Fully compatible**

Old Excel files will still work:
- If OS_Type is specified, auto-detection is skipped
- Domain column is optional, will be added as blank if missing
- All existing functionality preserved

To leverage new features:
1. Recreate template: `--create-template` to see new format
2. Leave OS_Type blank or set to "auto" for auto-detection
3. Add Domain column for Windows domain authentication

### Example Migration

**v1.0 Format (still works):**
```
IP_or_CIDR | OS_Type | Username | Password
10.0.0.5   | Windows | admin    | pass123
```

**v1.1 Format (recommended):**
```
IP_or_CIDR | OS_Type | Username | Password | Domain
10.0.0.5   | auto    | admin    | pass123  |
```

**v1.1 with Domain:**
```
IP_or_CIDR | OS_Type | Username  | Password | Domain
10.0.0.5   | Windows | john.doe  | pass123  | CONTOSO
```

---

## Version 1.0 - Initial Release (2024-10-23)

### Features
- Unified Python utility for Linux and Windows readiness checks
- Excel-based input configuration
- CIDR notation support with automatic expansion
- Multi-threaded scanning (configurable concurrency)
- Color-coded Excel output with summary statistics

### Linux Checks
- SSH port 22 connectivity
- SSH authentication
- Sudo NOPASSWD availability
- Required commands: netstat, route, ifconfig, crontab
- Sudo permissions per command

### Windows Checks
- WinRM port 5985 connectivity
- WinRM authentication (local accounts only)
- Administrator privileges verification

### Files Included
- `discovery_readiness_check.py` - Main utility script
- `requirements.txt` - Python dependencies
- `README.md` - Complete documentation

### Requirements
- Python 3.7+
- Dependencies: pandas, openpyxl, paramiko, pywinrm, netaddr
- Execution platform: Ubuntu/RHEL Linux
